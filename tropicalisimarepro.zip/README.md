# Panel de Anunciantes — Tropicalísima Sensacional 107.7 FM

Este proyecto reemplaza el carrusel de anunciantes "escrito a mano" en el
HTML por uno que se administra desde un panel privado en `/admin`. Ya no
necesitas tocar código para agregar, editar, reordenar, activar/desactivar
o eliminar anunciantes.

## ¿Cómo funciona?

- Los datos de los anunciantes viven en una base de datos **SQLite**
  (`data/anunciantes.db`), usando el módulo `node:sqlite` que trae Node.js
  integrado (Node 22.5+) — no se instala ningún paquete externo para la
  base de datos, así que no hay compilación nativa que pueda fallar.
- Esa base de datos **se crea sola** la primera vez que ejecutas
  `node server.js`, y se siembra automáticamente con tus 8 anunciantes
  actuales (los datos de ejemplo están escritos directamente en
  `lib/db.js` — no hay ningún archivo `.json` de por medio).
- El panel `/admin` lee y escribe en esa base de datos a través de una
  API protegida por usuario/contraseña.
- La página pública (`/`, tu carrusel) pide los anunciantes activos a
  `/api/anunciantes` y los dibuja automáticamente. No hay que editar el
  HTML nunca más para gestionar anuncios.

## Requisitos en el VPS

- **Node.js 22.5 o superior** (necesario para `node:sqlite`, incluido en
  el propio Node — no se instala ningún paquete externo de base de
  datos, así que no hay compilación nativa ni dependencia de Python).
- Un proceso manager como **PM2** para mantenerlo corriendo (recomendado).
- Opcional pero recomendado: Nginx como proxy inverso + certificado SSL
  (Let's Encrypt / Certbot) para servir todo por HTTPS.

## Instalación

```bash
# 1. Sube esta carpeta completa a tu VPS (por ejemplo con scp, git o FTP)
cd tropicalisima-admin

# 2. Instala las dependencias
npm install

# 3. Crea tu archivo de variables de entorno a partir del ejemplo
cp .env.example .env
nano .env
```

### Atajo para pruebas locales (doble clic)

Además del método de arriba, en la carpeta hay dos scripts para arrancar
todo con un doble clic (instalan dependencias si hacen falta, encienden
el servidor y abren el navegador en `/admin` automáticamente):

- **Windows:** `iniciar-windows.bat`
- **Mac / Linux:** `iniciar-mac-linux.sh`

Importante: sigue sin poder abrirse `admin/login.html` o
`public/index.html` directamente con doble clic — estos scripts no
"saltan" esa regla, simplemente automatizan encender el servidor real
(`node server.js`) y abrir la URL correcta por ti. La página siempre se
carga a través de `http://localhost:3000/...`, nunca como `file://`.

Dentro de `.env` cambia obligatoriamente:

- `ADMIN_USER` y `ADMIN_PASSWORD`: tus credenciales reales del panel.
- `SESSION_SECRET`: cualquier texto largo y aleatorio (por ejemplo generado
  con `openssl rand -hex 32`).
- `PORT`: el puerto interno del servidor (por defecto 3000).

## Copiar tus imágenes actuales

Copia dentro de `public/img/` los archivos que ya usa tu página:
`logo.jpg`, `logo-sensacional-nav.png`, `favicon.png`,
`logoinformativo-player.png`. El HTML y CSS ya apuntan a esas rutas.

## Ejecutar en modo prueba

```bash
node server.js
```

Verás en consola algo como:

```
Tropicalísima corriendo en http://localhost:3000
Panel de administración en http://localhost:3000/admin
```

## Ejecutar en producción (recomendado: PM2)

```bash
npm install -g pm2
pm2 start server.js --name tropicalisima
pm2 save
pm2 startup   # sigue las instrucciones que te muestre para que arranque solo si el VPS se reinicia
```

## Poner Nginx delante (dominio propio + HTTPS)

Ejemplo de configuración de Nginx como proxy inverso hacia el puerto 3000:

```nginx
server {
    listen 80;
    server_name tudominio.com www.tudominio.com;

    location / {
        proxy_pass http://localhost:3000;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_cache_bypass $http_upgrade;
    }
}
```

Luego activa HTTPS con Certbot:

```bash
sudo certbot --nginx -d tudominio.com -d www.tudominio.com
```

Una vez tengas HTTPS activo, en `server.js` puedes dejar
`NODE_ENV=production` en tu `.env` para que la cookie de sesión exija
conexión segura (`secure: true`).

## Usar el panel

1. Entra a `https://tudominio.com/admin`.
2. Inicia sesión con el usuario/contraseña que pusiste en `.env`.
3. Desde ahí puedes:
   - **Agregar** un anunciante nuevo (puedes subir una foto directamente
     o pegar la URL de una imagen).
   - **Recortar y encuadrar** la foto que subas: al elegir un archivo se
     abre automáticamente una ventana donde puedes mover, hacer zoom y
     encuadrar la imagen en la misma proporción (4:3) con la que se ve
     en la tarjeta del carrusel — así lo que ves ahí es fiel a como
     quedará en el sitio. Puedes recortarla de nuevo antes de guardar
     si no quedó como querías.
   - **Editar** cualquier anunciante existente.
   - **Activar/Desactivar** un anuncio sin borrarlo (útil si un cliente
     pausa su pauta temporalmente).
   - **Reordenar** con las flechas ↑ / ↓ el orden en que aparecen en el
     carrusel.
   - **Eliminar** definitivamente un anunciante.

Los cambios se reflejan de inmediato: la próxima vez que alguien cargue
o recargue la página principal, verá el carrusel actualizado — sin que
nadie toque una sola línea de código.

## Respaldo de datos

Todo vive en `data/anunciantes.db` (el archivo de la base de datos SQLite).
Es buena práctica incluir esta carpeta en tus respaldos periódicos del VPS.
Los archivos `data/anunciantes.db-shm` y `data/anunciantes.db-wal` que
aparecen junto a él son temporales de SQLite mientras el servidor está
corriendo — no los borres manualmente mientras el proceso esté activo.

## Seguridad

- Cambia `ADMIN_PASSWORD` y `SESSION_SECRET` antes de desplegar — los
  valores del `.env.example` son solo de referencia.
- Sirve el sitio por HTTPS en producción para que la contraseña del panel
  no viaje sin cifrar.
- El archivo `.env` **no** debe subirse a ningún repositorio público.
