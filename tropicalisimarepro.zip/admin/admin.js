// ──────────────────────────────────────────────
// Panel de administración — lógica del dashboard
// ──────────────────────────────────────────────
const form = document.getElementById('anuncianteForm');
const listaEl = document.getElementById('listaAnunciantes');
const toastEl = document.getElementById('toast');
const formTitle = document.getElementById('formTitle');
const guardarBtn = document.getElementById('guardarBtn');
const cancelarEdicionBtn = document.getElementById('cancelarEdicionBtn');
const logoutBtn = document.getElementById('logoutBtn');

const imagenFileInput = document.getElementById('imagenFile');
const imagenFileMovilAlterno = document.getElementById('imagenFileMovilAlterno');
const imagenActualUrlInput = document.getElementById('imagenActualUrl');
const imagenMovilActualUrlInput = document.getElementById('imagenMovilActualUrl');
const previewWrapperDesktop = document.getElementById('previewWrapperDesktop');
const previewImgDesktop = document.getElementById('previewImgDesktop');
const recortarDeNuevoDesktopBtn = document.getElementById('recortarDeNuevoDesktopBtn');
const previewWrapperMovil = document.getElementById('previewWrapperMovil');
const previewImgMovil = document.getElementById('previewImgMovil');
const recortarDeNuevoMovilBtn = document.getElementById('recortarDeNuevoMovilBtn');
const elegirOtraImagenMovilBtn = document.getElementById('elegirOtraImagenMovilBtn');

const cropModalOverlay = document.getElementById('cropModalOverlay');
const cropModalTitulo = document.getElementById('cropModalTitulo');
const cropModalHint = document.getElementById('cropModalHint');
const cropperImageEl = document.getElementById('cropperImage');
const cropConfirmBtn = document.getElementById('cropConfirmBtn');
const cropCancelBtn = document.getElementById('cropCancelBtn');
const cropElegirOtraBtn = document.getElementById('cropElegirOtraBtn');

// Proporción de la imagen dentro de la tarjeta del carrusel (ver
// .anunciante-img-wrapper en css/styles.css) — se usa como guía del
// recuadro de recorte para que lo que ves aquí sea fiel a lo que se
// verá en el sitio.
//
// ESCRITORIO: la tarjeta es horizontal (flex-direction: row) y la
// imagen ocupa 45% del ancho con la altura completa de la tarjeta
// (~280px) → proporción 4:3.
//
// MÓVIL (@media max-width: 480px en public/css/styles.css): la
// tarjeta cambia a columna (flex-direction: column) y la imagen pasa
// a ser una franja panorámica de ancho completo con una altura de
// ~120–180px → proporción mucho más ancha, aprox. 12:5 (2.4:1).
const CONFIG_RECORTE = {
  desktop: {
    proporcion: 4 / 3,
    etiqueta: '4:3',
    ancho: 800,
    alto: Math.round(800 / (4 / 3)),
    titulo: 'Encuadra la imagen — Escritorio',
    hint: 'Ajusta el recuadro para que coincida con cómo se verá la tarjeta del carrusel en la versión de escritorio (proporción 4:3). Puedes mover y hacer zoom con el mouse o los dedos.'
  },
  movil: {
    proporcion: 12 / 5,
    etiqueta: '12:5 (panorámica)',
    ancho: 1000,
    alto: Math.round(1000 / (12 / 5)),
    titulo: 'Encuadra la imagen — Tarjeta móvil',
    hint: 'Ajusta el recuadro para la franja panorámica de la tarjeta del carrusel en teléfonos (proporción 12:5). Puedes usar un encuadre distinto al de escritorio para que se vea bien también en el celular.'
  }
};

let anunciantes = [];
let editandoId = null;
let cropperInstancia = null;
let imagenOriginalDataUrl = null;      // original subido para el recorte de escritorio (y de móvil, si no se elige otro)
let imagenMovilOriginalDataUrl = null; // original alterno elegido específicamente para el recorte de móvil (opcional)
let imagenRecortadaBlob = null;      // resultado del recorte para escritorio, listo para subir
let imagenMovilRecortadaBlob = null; // resultado del recorte para móvil, listo para subir
let pasoRecorteActual = 'desktop';   // 'desktop' | 'movil' — a qué recorte corresponde el modal abierto
let encadenarPasoMovil = false;      // si al confirmar el recorte de escritorio se debe continuar con el de móvil

function mostrarToast(mensaje, esError = false) {
  toastEl.textContent = mensaje;
  toastEl.classList.toggle('error', esError);
  toastEl.classList.add('show');
  setTimeout(() => toastEl.classList.remove('show'), 2800);
}

function escapeHtml(str = '') {
  return str.replace(/[&<>"']/g, (c) => ({
    '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;'
  }[c]));
}

// ---------- Cargar lista ----------
async function cargarAnunciantes() {
  try {
    const res = await fetch('/api/admin/anunciantes');
    if (res.status === 401) {
      window.location.href = '/admin/login.html';
      return;
    }
    anunciantes = await res.json();
    renderizarLista();
  } catch (err) {
    listaEl.innerHTML = '<div class="empty-state">No se pudo cargar la lista de anunciantes.</div>';
  }
}

function renderizarLista() {
  if (!anunciantes.length) {
    listaEl.innerHTML = '<div class="empty-state">Aún no has agregado ningún anunciante.</div>';
    return;
  }

  const ordenados = [...anunciantes].sort((a, b) => a.orden - b.orden);

  listaEl.innerHTML = ordenados.map((a, index) => `
    <div class="anunciante-item ${a.activo ? '' : 'inactivo'}" data-id="${a.id}">
      <img src="${escapeHtml(a.imagen || '')}" alt="${escapeHtml(a.nombre)}" onerror="this.style.visibility='hidden'">
      <div class="info">
        <span class="categoria-tag">${escapeHtml(a.categoria)}</span>
        <div class="nombre">${escapeHtml(a.nombre)}</div>
        <div class="desc">${escapeHtml(a.descripcion || '')}</div>
      </div>
      <div class="item-actions">
        <div class="row-btns">
          <button class="icon-btn" title="Subir" data-accion="subir" ${index === 0 ? 'disabled' : ''}>↑</button>
          <button class="icon-btn" title="Bajar" data-accion="bajar" ${index === ordenados.length - 1 ? 'disabled' : ''}>↓</button>
        </div>
        <div class="row-btns">
          <button class="icon-btn" title="${a.activo ? 'Desactivar' : 'Activar'}" data-accion="toggle">${a.activo ? '👁️' : '🚫'}</button>
          <button class="icon-btn" title="Editar" data-accion="editar">✏️</button>
          <button class="icon-btn" title="Eliminar" data-accion="eliminar">🗑️</button>
        </div>
      </div>
    </div>
  `).join('');
}

listaEl.addEventListener('click', async (e) => {
  const btn = e.target.closest('button[data-accion]');
  if (!btn) return;

  const item = btn.closest('.anunciante-item');
  const id = item.dataset.id;
  const accion = btn.dataset.accion;

  if (accion === 'editar') return editarAnunciante(id);
  if (accion === 'eliminar') return eliminarAnunciante(id);
  if (accion === 'toggle') return toggleActivo(id);
  if (accion === 'subir') return moverOrden(id, -1);
  if (accion === 'bajar') return moverOrden(id, 1);
});

function editarAnunciante(id) {
  const a = anunciantes.find((x) => x.id === id);
  if (!a) return;

  editandoId = id;
  document.getElementById('anuncianteId').value = id;
  document.getElementById('categoria').value = a.categoria || '';
  document.getElementById('nombre').value = a.nombre || '';
  document.getElementById('descripcion').value = a.descripcion || '';
  document.getElementById('ubicacion').value = a.ubicacion || '';
  document.getElementById('instagram').value = a.instagram || '';
  document.getElementById('activo').checked = !!a.activo;

  prepararImagenParaEdicion(a);

  formTitle.textContent = `Editando: ${a.nombre}`;
  guardarBtn.textContent = 'Guardar cambios';
  cancelarEdicionBtn.style.display = 'inline-flex';
  window.scrollTo({ top: 0, behavior: 'smooth' });
}

function cancelarEdicion() {
  editandoId = null;
  form.reset();
  document.getElementById('anuncianteId').value = '';
  document.getElementById('activo').checked = true;
  limpiarEstadoDeImagen();
  formTitle.textContent = 'Agregar nuevo anunciante';
  guardarBtn.textContent = 'Agregar anunciante';
  cancelarEdicionBtn.style.display = 'none';
}
cancelarEdicionBtn.addEventListener('click', cancelarEdicion);

async function eliminarAnunciante(id) {
  const a = anunciantes.find((x) => x.id === id);
  if (!confirm(`¿Eliminar "${a ? a.nombre : ''}"? Esta acción no se puede deshacer.`)) return;

  try {
    const res = await fetch(`/api/admin/anunciantes/${id}`, { method: 'DELETE' });
    if (!res.ok) throw new Error('No se pudo eliminar');
    mostrarToast('Anunciante eliminado');
    await cargarAnunciantes();
  } catch (err) {
    mostrarToast(err.message, true);
  }
}

async function toggleActivo(id) {
  const a = anunciantes.find((x) => x.id === id);
  if (!a) return;

  try {
    const res = await fetch(`/api/admin/anunciantes/${id}`, {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ activo: !a.activo })
    });
    if (!res.ok) throw new Error('No se pudo actualizar');
    await cargarAnunciantes();
  } catch (err) {
    mostrarToast(err.message, true);
  }
}

async function moverOrden(id, direccion) {
  const ordenados = [...anunciantes].sort((a, b) => a.orden - b.orden);
  const index = ordenados.findIndex((a) => a.id === id);
  const nuevoIndex = index + direccion;

  if (nuevoIndex < 0 || nuevoIndex >= ordenados.length) return;

  const temp = ordenados[index];
  ordenados[index] = ordenados[nuevoIndex];
  ordenados[nuevoIndex] = temp;

  try {
    const res = await fetch('/api/admin/anunciantes/reordenar', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ ids: ordenados.map((a) => a.id) })
    });
    if (!res.ok) throw new Error('No se pudo reordenar');
    await cargarAnunciantes();
  } catch (err) {
    mostrarToast(err.message, true);
  }
}

// ──────────────────────────────────────────────
// Recorte y encuadre de la imagen (Cropper.js)
// ──────────────────────────────────────────────

function limpiarEstadoDeImagen() {
  imagenOriginalDataUrl = null;
  imagenMovilOriginalDataUrl = null;
  imagenRecortadaBlob = null;
  imagenMovilRecortadaBlob = null;
  imagenFileInput.value = '';
  imagenFileMovilAlterno.value = '';
  imagenActualUrlInput.value = '';
  imagenMovilActualUrlInput.value = '';
  previewWrapperDesktop.style.display = 'none';
  previewImgDesktop.removeAttribute('src');
  previewWrapperMovil.style.display = 'none';
  previewImgMovil.removeAttribute('src');
}

// Al editar un anunciante existente se muestran sus imágenes actuales
// (guardadas como URL) en las vistas previas, sin volver a pedir el
// archivo. Si el usuario no sube nada nuevo, esas URLs se conservan
// tal cual al guardar.
function prepararImagenParaEdicion(a) {
  imagenOriginalDataUrl = null;
  imagenMovilOriginalDataUrl = null;
  imagenRecortadaBlob = null;
  imagenMovilRecortadaBlob = null;
  imagenFileInput.value = '';
  imagenFileMovilAlterno.value = '';

  imagenActualUrlInput.value = a.imagen || '';
  imagenMovilActualUrlInput.value = a.imagenMovil || '';

  if (a.imagen) {
    previewImgDesktop.src = a.imagen;
    previewWrapperDesktop.style.display = 'flex';
  } else {
    previewWrapperDesktop.style.display = 'none';
    previewImgDesktop.removeAttribute('src');
  }

  const imgMovilActual = a.imagenMovil || a.imagen;
  if (imgMovilActual) {
    previewImgMovil.src = imgMovilActual;
    previewWrapperMovil.style.display = 'flex';
  } else {
    previewWrapperMovil.style.display = 'none';
    previewImgMovil.removeAttribute('src');
  }
}

imagenFileInput.addEventListener('change', () => {
  const archivo = imagenFileInput.files[0];
  if (!archivo) return;

  const lector = new FileReader();
  lector.onload = (e) => {
    imagenOriginalDataUrl = e.target.result;
    imagenMovilOriginalDataUrl = null;
    imagenRecortadaBlob = null;
    imagenMovilRecortadaBlob = null;
    previewWrapperDesktop.style.display = 'none';
    previewWrapperMovil.style.display = 'none';
    // Con una imagen nueva, se pide primero el recorte de escritorio
    // y, al confirmarlo, se encadena automáticamente el de móvil.
    abrirModalRecorte(imagenOriginalDataUrl, 'desktop', true);
  };
  lector.readAsDataURL(archivo);
});

// "Elegir otra imagen" para móvil: por si la imagen de escritorio no
// queda bien de proporción en la franja del carrusel móvil, o si
// simplemente se quiere usar una foto distinta ahí.
function abrirSelectorImagenMovilAlterna() {
  imagenFileMovilAlterno.click();
}

imagenFileMovilAlterno.addEventListener('change', () => {
  const archivo = imagenFileMovilAlterno.files[0];
  if (!archivo) return;

  const lector = new FileReader();
  lector.onload = (e) => {
    imagenMovilOriginalDataUrl = e.target.result;
    abrirModalRecorte(imagenMovilOriginalDataUrl, 'movil', false);
  };
  lector.readAsDataURL(archivo);
});

elegirOtraImagenMovilBtn.addEventListener('click', abrirSelectorImagenMovilAlterna);
cropElegirOtraBtn.addEventListener('click', abrirSelectorImagenMovilAlterna);

// "Recortar de nuevo" de cada vista previa: reabre el modal solo para
// ese formato puntual, sin encadenar el otro paso. El de móvil usa la
// imagen alterna si se eligió una, o si no, la misma de escritorio.
recortarDeNuevoDesktopBtn.addEventListener('click', () => {
  if (imagenOriginalDataUrl) abrirModalRecorte(imagenOriginalDataUrl, 'desktop', false);
});

recortarDeNuevoMovilBtn.addEventListener('click', () => {
  const origen = imagenMovilOriginalDataUrl || imagenOriginalDataUrl;
  if (origen) abrirModalRecorte(origen, 'movil', false);
});

function abrirModalRecorte(dataUrl, paso = 'desktop', encadenarMovil = false) {
  pasoRecorteActual = paso;
  encadenarPasoMovil = encadenarMovil;
  const cfg = CONFIG_RECORTE[paso];

  cropModalTitulo.textContent = cfg.titulo;
  cropModalHint.textContent = cfg.hint;
  // En el paso de móvil, "Cancelar" funciona como "omitir": conserva el
  // recorte de escritorio ya hecho y usa esa misma imagen para el celular.
  cropCancelBtn.textContent = paso === 'movil' ? 'Omitir (usar la de escritorio)' : 'Cancelar';
  // "Elegir otra imagen" solo tiene sentido en el paso de móvil.
  cropElegirOtraBtn.style.display = paso === 'movil' ? 'inline-flex' : 'none';

  cropModalOverlay.classList.add('show');

  function inicializarCropper() {
    if (cropperInstancia) {
      cropperInstancia.destroy();
      cropperInstancia = null;
    }
    cropperInstancia = new Cropper(cropperImageEl, {
      aspectRatio: cfg.proporcion,
      viewMode: 1,
      autoCropArea: 1,
      background: false,
      responsive: true,
      dragMode: 'move'
    });
  }

  // Cuando se encadena el recorte de móvil usando LA MISMA imagen que
  // ya estaba cargada (p. ej. justo después de recortar la de
  // escritorio), el <img> no cambia de "src" y el navegador NO vuelve
  // a disparar el evento "load" — por eso antes se quedaba con el
  // recorte anterior (4:3) en vez de pasar a la proporción de móvil.
  // Si la imagen ya es esa misma y ya está cargada, se reinicia el
  // recorte de una vez; si es una imagen nueva (archivo recién
  // elegido), se espera a que cargue como antes.
  if (cropperImageEl.getAttribute('src') === dataUrl && cropperImageEl.complete) {
    inicializarCropper();
  } else {
    cropperImageEl.onload = inicializarCropper;
    cropperImageEl.src = dataUrl;
  }
}

function cerrarModalRecorte() {
  cropModalOverlay.classList.remove('show');
  if (cropperInstancia) {
    cropperInstancia.destroy();
    cropperInstancia = null;
  }
}

cropCancelBtn.addEventListener('click', () => {
  const eraPasoDesktop = pasoRecorteActual === 'desktop';
  cerrarModalRecorte();
  // Si cancela el recorte de escritorio sin haber recortado antes, se
  // limpia la selección de archivo. En el paso de móvil, "cancelar" solo
  // omite ese recorte (queda el de escritorio como imagen para ambos).
  if (eraPasoDesktop && !imagenRecortadaBlob) {
    imagenFileInput.value = '';
    imagenOriginalDataUrl = null;
  }
});

cropConfirmBtn.addEventListener('click', () => {
  if (!cropperInstancia) return;

  const cfg = CONFIG_RECORTE[pasoRecorteActual];
  const canvas = cropperInstancia.getCroppedCanvas({
    width: cfg.ancho,
    height: cfg.alto,
    imageSmoothingEnabled: true,
    imageSmoothingQuality: 'high'
  });

  canvas.toBlob((blob) => {
    if (!blob) {
      mostrarToast('No se pudo procesar el recorte, intenta de nuevo', true);
      return;
    }

    if (pasoRecorteActual === 'movil') {
      imagenMovilRecortadaBlob = blob;
      previewImgMovil.src = URL.createObjectURL(blob);
      previewWrapperMovil.style.display = 'flex';
    } else {
      imagenRecortadaBlob = blob;
      previewImgDesktop.src = URL.createObjectURL(blob);
      previewWrapperDesktop.style.display = 'flex';
    }

    // Tras confirmar el recorte de escritorio en el flujo de "imagen
    // nueva", se continúa automáticamente con el recorte para móvil.
    if (pasoRecorteActual === 'desktop' && encadenarPasoMovil) {
      abrirModalRecorte(imagenOriginalDataUrl, 'movil', false);
    } else {
      cerrarModalRecorte();
    }
  }, 'image/jpeg', 0.9);
});

// ---------- Guardar (crear o editar) ----------
form.addEventListener('submit', async (e) => {
  e.preventDefault();
  guardarBtn.disabled = true;

  try {
    let imagenUrl = imagenActualUrlInput.value.trim();
    let imagenMovilUrl = imagenMovilActualUrlInput.value.trim();

    if (imagenRecortadaBlob) {
      const fd = new FormData();
      fd.append('imagen', imagenRecortadaBlob, 'recorte-escritorio.jpg');
      const resUpload = await fetch('/api/admin/upload', { method: 'POST', body: fd });
      const dataUpload = await resUpload.json();
      if (!resUpload.ok) throw new Error(dataUpload.error || 'Error subiendo la imagen de escritorio');
      imagenUrl = dataUpload.url;
    }

    if (imagenMovilRecortadaBlob) {
      const fd = new FormData();
      fd.append('imagen', imagenMovilRecortadaBlob, 'recorte-movil.jpg');
      const resUpload = await fetch('/api/admin/upload', { method: 'POST', body: fd });
      const dataUpload = await resUpload.json();
      if (!resUpload.ok) throw new Error(dataUpload.error || 'Error subiendo la imagen para móvil');
      imagenMovilUrl = dataUpload.url;
    }

    if (!imagenUrl) {
      throw new Error('Debes subir una imagen para el anunciante');
    }

    const payload = {
      categoria: document.getElementById('categoria').value.trim(),
      nombre: document.getElementById('nombre').value.trim(),
      descripcion: document.getElementById('descripcion').value.trim(),
      ubicacion: document.getElementById('ubicacion').value.trim(),
      instagram: document.getElementById('instagram').value.trim(),
      imagen: imagenUrl,
      imagenMovil: imagenMovilUrl,
      activo: document.getElementById('activo').checked
    };

    const url = editandoId ? `/api/admin/anunciantes/${editandoId}` : '/api/admin/anunciantes';
    const method = editandoId ? 'PUT' : 'POST';

    const res = await fetch(url, {
      method,
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload)
    });

    const data = await res.json();
    if (!res.ok) throw new Error(data.error || 'No se pudo guardar');

    mostrarToast(editandoId ? 'Anunciante actualizado' : 'Anunciante agregado');
    cancelarEdicion();
    await cargarAnunciantes();
  } catch (err) {
    mostrarToast(err.message, true);
  } finally {
    guardarBtn.disabled = false;
  }
});

// ---------- Logout ----------
logoutBtn.addEventListener('click', async () => {
  await fetch('/api/logout', { method: 'POST' });
  window.location.href = '/admin/login.html';
});

cargarAnunciantes();
