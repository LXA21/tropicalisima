require('dotenv').config();

const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const express = require('express');
const session = require('express-session');
const bcrypt = require('bcryptjs');
const multer = require('multer');
const db = require('./lib/db');

const app = express();

const PORT = process.env.PORT || 3000;
const ADMIN_USER = process.env.ADMIN_USER || 'admin';
const SESSION_SECRET = process.env.SESSION_SECRET || 'cambia-esto-por-favor';

// ──────────────────────────────────────────────
// Rol de esta instancia (para separar backend/web en Docker)
// ──────────────────────────────────────────────
// - "backend": solo monta /admin, la API de administración y el login.
//              No sirve el sitio público ni /api/anunciantes.
// - "web":     solo monta el sitio público y /api/anunciantes.
//              No monta /admin ni la API de administración — aunque
//              alguien llegue a este puerto/subdominio directo, esas
//              rutas simplemente no existen en esta instancia (404).
// - "full" (o sin definir): monta todo en un solo proceso, como antes
//              — es el valor por defecto para seguir usando el
//              proyecto igual que hasta ahora fuera de Docker.
const ROLE = (process.env.ROLE || 'full').toLowerCase();
const SIRVE_BACKEND = ROLE === 'backend' || ROLE === 'full';
const SIRVE_WEB = ROLE === 'web' || ROLE === 'full';

// La contraseña se guarda siempre encriptada en memoria (nunca en texto plano)
const ADMIN_PASSWORD_HASH = bcrypt.hashSync(
  process.env.ADMIN_PASSWORD || 'admin123',
  10
);

const UPLOADS_DIR = path.join(__dirname, 'public', 'img', 'anunciantes');

function generarId() {
  return crypto.randomBytes(6).toString('hex');
}

// ──────────────────────────────────────────────
// Middlewares base
// ──────────────────────────────────────────────
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// La sesión (cookies de login) solo hace falta donde vive el panel de
// administración.
if (SIRVE_BACKEND) {
  app.use(
    session({
      secret: SESSION_SECRET,
      resave: false,
      saveUninitialized: false,
      cookie: {
        httpOnly: true,
        // "secure: true" exige HTTPS. Actívalo cuando tu VPS ya tenga
        // certificado SSL en producción.
        secure: process.env.NODE_ENV === 'production',
        maxAge: 1000 * 60 * 60 * 8 // 8 horas
      }
    })
  );
}

// SOLO PARA PRUEBAS LOCALES: si en tu .env pones DISABLE_LOGIN=true,
// el panel /admin queda abierto sin pedir usuario/contraseña.
// ¡NUNCA actives esto en el VPS/producción! Déjalo en "false" (o bórralo)
// antes de desplegar.
const LOGIN_DESACTIVADO = process.env.DISABLE_LOGIN === 'true';
if (LOGIN_DESACTIVADO && SIRVE_BACKEND) {
  console.warn('⚠️  DISABLE_LOGIN=true — el panel /admin está SIN contraseña. Solo para pruebas locales.');
}

function requireAuth(req, res, next) {
  if (LOGIN_DESACTIVADO) return next();
  if (req.session && req.session.autenticado) return next();
  return res.status(401).json({ error: 'No autenticado' });
}

function requireAuthPagina(req, res, next) {
  if (LOGIN_DESACTIVADO) return next();
  if (req.session && req.session.autenticado) return next();
  return res.redirect('/admin/login.html');
}

// La carpeta de imágenes subidas la necesitan ambos roles: el backend
// escribe ahí y el sitio web las sirve como estáticos — se crea sin
// importar el rol por si el volumen llega vacío.
if (!fs.existsSync(UPLOADS_DIR)) fs.mkdirSync(UPLOADS_DIR, { recursive: true });

// ──────────────────────────────────────────────
// BACKEND: autenticación + API de administración + panel /admin
// ──────────────────────────────────────────────
if (SIRVE_BACKEND) {
  const storage = multer.diskStorage({
    destination: (req, file, cb) => cb(null, UPLOADS_DIR),
    filename: (req, file, cb) => {
      const ext = path.extname(file.originalname).toLowerCase();
      cb(null, `${Date.now()}-${crypto.randomBytes(4).toString('hex')}${ext}`);
    }
  });

  const upload = multer({
    storage,
    limits: { fileSize: 5 * 1024 * 1024 }, // 5MB máx
    fileFilter: (req, file, cb) => {
      const permitidos = ['.jpg', '.jpeg', '.png', '.webp', '.gif'];
      const ext = path.extname(file.originalname).toLowerCase();
      if (!permitidos.includes(ext)) {
        return cb(new Error('Formato de imagen no permitido'));
      }
      cb(null, true);
    }
  });

  // -- Autenticación --
  app.post('/api/login', (req, res) => {
    const { usuario, password } = req.body;

    if (usuario !== ADMIN_USER || !bcrypt.compareSync(password || '', ADMIN_PASSWORD_HASH)) {
      return res.status(401).json({ error: 'Usuario o contraseña incorrectos' });
    }

    req.session.autenticado = true;
    req.session.usuario = usuario;
    res.json({ ok: true });
  });

  app.post('/api/logout', (req, res) => {
    req.session.destroy(() => res.json({ ok: true }));
  });

  app.get('/api/sesion', (req, res) => {
    res.json({ autenticado: LOGIN_DESACTIVADO ? true : !!(req.session && req.session.autenticado) });
  });

  // -- API privada — panel de administración (requiere sesión) --
  app.get('/api/admin/anunciantes', requireAuth, (req, res) => {
    res.json(db.obtenerTodos());
  });

  app.post('/api/admin/anunciantes', requireAuth, (req, res) => {
    const { categoria, nombre, descripcion, ubicacion, imagen, imagenMovil, instagram, activo } = req.body;

    if (!nombre || !categoria) {
      return res.status(400).json({ error: 'Nombre y categoría son obligatorios' });
    }

    const nuevo = db.crear({
      id: generarId(),
      activo: activo !== undefined ? !!activo : true,
      categoria,
      nombre,
      descripcion,
      ubicacion,
      imagen,
      imagenMovil,
      instagram
    });

    res.status(201).json(nuevo);
  });

  app.put('/api/admin/anunciantes/:id', requireAuth, (req, res) => {
    const actualizado = db.actualizar(req.params.id, req.body);
    if (!actualizado) return res.status(404).json({ error: 'Anunciante no encontrado' });
    res.json(actualizado);
  });

  app.delete('/api/admin/anunciantes/:id', requireAuth, (req, res) => {
    const eliminado = db.eliminar(req.params.id);
    if (!eliminado) return res.status(404).json({ error: 'Anunciante no encontrado' });
    res.json({ ok: true });
  });

  // Reordenar: recibe un arreglo de ids en el nuevo orden deseado
  app.post('/api/admin/anunciantes/reordenar', requireAuth, (req, res) => {
    const { ids } = req.body;
    if (!Array.isArray(ids)) return res.status(400).json({ error: 'Se esperaba un arreglo de ids' });

    db.reordenar(ids);
    res.json({ ok: true });
  });

  app.post('/api/admin/upload', requireAuth, (req, res) => {
    upload.single('imagen')(req, res, (err) => {
      if (err) return res.status(400).json({ error: err.message });
      if (!req.file) return res.status(400).json({ error: 'No se recibió ninguna imagen' });
      res.json({ url: `/img/anunciantes/${req.file.filename}` });
    });
  });

  // -- Páginas del panel de administración --
  app.get('/admin', requireAuthPagina, (req, res) => {
    res.sendFile(path.join(__dirname, 'admin', 'dashboard.html'));
  });
  app.get('/admin/', requireAuthPagina, (req, res) => {
    res.sendFile(path.join(__dirname, 'admin', 'dashboard.html'));
  });
  app.get('/admin/dashboard.html', requireAuthPagina, (req, res) => {
    res.sendFile(path.join(__dirname, 'admin', 'dashboard.html'));
  });

  app.use('/admin', express.static(path.join(__dirname, 'admin')));

  // En una instancia que SOLO es backend (sin sitio público), entrar a
  // "/" lleva directo al panel en vez de dar 404 — pensado para cuando
  // este contenedor vive en su propio subdominio (p. ej. admin.tudominio.com).
  if (!SIRVE_WEB) {
    app.get('/', (req, res) => res.redirect('/admin'));
  }
}

// ──────────────────────────────────────────────
// WEB: API pública (la usa el carrusel) + sitio público estático
// ──────────────────────────────────────────────
if (SIRVE_WEB) {
  app.get('/api/anunciantes', (req, res) => {
    res.json(db.obtenerActivos());
  });

  app.use(express.static(path.join(__dirname, 'public')));
}

app.listen(PORT, () => {
  const nombreRol = { backend: 'BACKEND (admin + API privada)', web: 'WEB (sitio público)', full: 'COMPLETO (todo en un proceso)' }[ROLE] || ROLE;
  console.log(`Tropicalísima [${nombreRol}] corriendo en http://localhost:${PORT}`);
  if (SIRVE_WEB) console.log(`  Sitio público: http://localhost:${PORT}/`);
  if (SIRVE_BACKEND) console.log(`  Panel de administración: http://localhost:${PORT}/admin`);
});

