Si usas certificados SSL en archivo (en vez de otro mecanismo), puedes
colocarlos aquí. Esta carpeta se monta en el contenedor nginx en
/etc/nginx/certs/.
