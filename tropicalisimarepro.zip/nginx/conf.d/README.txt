Pon aquí tus archivos .conf de nginx (dominios, server_name, SSL, etc).
Este directorio se monta en el contenedor nginx en /etc/nginx/conf.d/.

Dentro de la red interna "radio_net" del docker-compose, los upstreams
a los que puedes apuntar con proxy_pass son:

  http://radio_backend:2020   (panel /admin + API privada)
  http://radio_web:4040       (sitio público + /api/anunciantes)
