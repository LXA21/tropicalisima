require('dotenv').config();

const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const express = require('express');
const session = require('express-session');
const bcrypt = require('bcryptjs');
const multer = require('multer');
const db = require('./lib/db');

const app = express();

const PORT = process.env.PORT || 3000;
const ADMIN_USER = process.env.ADMIN_USER || 'admin';
const SESSION_SECRET = process.env.SESSION_SECRET || 'cambia-esto-por-favor';

// ──────────────────────────────────────────────
// ROLE: separa qué sirve cada contenedor.
//   - "backend" -> SOLO /admin + API de administración.
//   - "web"     -> SOLO el sitio público + /api/anunciantes.
//   - sin ROLE (ej. corriendo "node server.js" localmente sin Docker)
//     -> sirve TODO, como antes, para no romper el flujo de desarrollo.
// ──────────────────────────────────────────────
const ROLE = process.env.ROLE || 'full';
const SIRVE_BACKEND = ROLE === 'backend' || ROLE === 'full';
const SIRVE_WEB = ROLE === 'web' || ROLE === 'full';

// Necesario para que las cookies de sesión "secure" funcionen detrás
// de un proxy reverso (nginx) que termina el TLS: sin esto, Express
// nunca ve la conexión como https y express-session descarta la
// cookie de sesión en producción (el login "no se queda pegado").
app.set('trust proxy', 1);

// La contraseña se guarda siempre encriptada en memoria (nunca en texto plano)
const ADMIN_PASSWORD_HASH = bcrypt.hashSync(
  process.env.ADMIN_PASSWORD || 'admin123',
  10
);

const UPLOADS_DIR = path.join(__dirname, 'public', 'img', 'anunciantes');

function generarId() {
  return crypto.randomBytes(6).toString('hex');
}

// ──────────────────────────────────────────────
// Middlewares base
// ──────────────────────────────────────────────
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// La sesión solo hace falta donde vive el login (rol backend/full),
// pero registrarla siempre es inofensivo y simplifica el código.
app.use(
  session({
    secret: SESSION_SECRET,
    resave: false,
    saveUninitialized: false,
    cookie: {
      httpOnly: true,
      // "secure: true" exige HTTPS. Actívalo cuando tu VPS ya tenga
      // certificado SSL en producción.
      secure: process.env.NODE_ENV === 'production',
      maxAge: 1000 * 60 * 60 * 8 // 8 horas
    }
  })
);

// SOLO PARA PRUEBAS LOCALES: si en tu .env pones DISABLE_LOGIN=true,
// el panel /admin queda abierto sin pedir usuario/contraseña.
// ¡NUNCA actives esto en el VPS/producción! Déjalo en "false" (o bórralo)
// antes de desplegar.
const LOGIN_DESACTIVADO = process.env.DISABLE_LOGIN === 'true';
if (LOGIN_DESACTIVADO) {
  console.warn('⚠️  DISABLE_LOGIN=true — el panel /admin está SIN contraseña. Solo para pruebas locales.');
}

function requireAuth(req, res, next) {
  if (LOGIN_DESACTIVADO) return next();
  if (req.session && req.session.autenticado) return next();
  return res.status(401).json({ error: 'No autenticado' });
}

function requireAuthPagina(req, res, next) {
  if (LOGIN_DESACTIVADO) return next();
  if (req.session && req.session.autenticado) return next();
  return res.redirect('/admin/login.html');
}

// ──────────────────────────────────────────────
// Subida de imágenes
// ──────────────────────────────────────────────
if (!fs.existsSync(UPLOADS_DIR)) fs.mkdirSync(UPLOADS_DIR, { recursive: true });

const storage = multer.diskStorage({
  destination: (req, file, cb) => cb(null, UPLOADS_DIR),
  filename: (req, file, cb) => {
    const ext = path.extname(file.originalname).toLowerCase();
    cb(null, `${Date.now()}-${crypto.randomBytes(4).toString('hex')}${ext}`);
  }
});

const upload = multer({
  storage,
  limits: { fileSize: 5 * 1024 * 1024 }, // 5MB máx
  fileFilter: (req, file, cb) => {
    const permitidos = ['.jpg', '.jpeg', '.png', '.webp', '.gif'];
    const ext = path.extname(file.originalname).toLowerCase();
    if (!permitidos.includes(ext)) {
      return cb(new Error('Formato de imagen no permitido'));
    }
    cb(null, true);
  }
});

if (SIRVE_BACKEND) {
  // ──────────────────────────────────────────────
  // Rutas de autenticación (solo rol backend/full)
  // ──────────────────────────────────────────────
  app.post('/api/login', (req, res) => {
    const { usuario, password } = req.body;

    if (usuario !== ADMIN_USER || !bcrypt.compareSync(password || '', ADMIN_PASSWORD_HASH)) {
      return res.status(401).json({ error: 'Usuario o contraseña incorrectos' });
    }

    req.session.autenticado = true;
    req.session.usuario = usuario;
    res.json({ ok: true });
  });

  app.post('/api/logout', (req, res) => {
    req.session.destroy(() => res.json({ ok: true }));
  });

  app.get('/api/sesion', (req, res) => {
    res.json({ autenticado: LOGIN_DESACTIVADO ? true : !!(req.session && req.session.autenticado) });
  });

  // ──────────────────────────────────────────────
  // API privada — panel de administración (requiere sesión)
  // ──────────────────────────────────────────────
  app.get('/api/admin/anunciantes', requireAuth, (req, res) => {
    res.json(db.obtenerTodos());
  });

  app.post('/api/admin/anunciantes', requireAuth, (req, res) => {
    const { categoria, nombre, descripcion, ubicacion, imagen, imagenMovil, instagram, activo } = req.body;

    if (!nombre || !categoria) {
      return res.status(400).json({ error: 'Nombre y categoría son obligatorios' });
    }

    const nuevo = db.crear({
      id: generarId(),
      activo: activo !== undefined ? !!activo : true,
      categoria,
      nombre,
      descripcion,
      ubicacion,
      imagen,
      imagenMovil,
      instagram
    });

    res.status(201).json(nuevo);
  });

  app.put('/api/admin/anunciantes/:id', requireAuth, (req, res) => {
    const actualizado = db.actualizar(req.params.id, req.body);
    if (!actualizado) return res.status(404).json({ error: 'Anunciante no encontrado' });
    res.json(actualizado);
  });

  app.delete('/api/admin/anunciantes/:id', requireAuth, (req, res) => {
    const eliminado = db.eliminar(req.params.id);
    if (!eliminado) return res.status(404).json({ error: 'Anunciante no encontrado' });
    res.json({ ok: true });
  });

  // Reordenar: recibe un arreglo de ids en el nuevo orden deseado
  app.post('/api/admin/anunciantes/reordenar', requireAuth, (req, res) => {
    const { ids } = req.body;
    if (!Array.isArray(ids)) return res.status(400).json({ error: 'Se esperaba un arreglo de ids' });

    db.reordenar(ids);
    res.json({ ok: true });
  });

  app.post('/api/admin/upload', requireAuth, (req, res) => {
    upload.single('imagen')(req, res, (err) => {
      if (err) return res.status(400).json({ error: err.message });
      if (!req.file) return res.status(400).json({ error: 'No se recibió ninguna imagen' });
      res.json({ url: `/img/anunciantes/${req.file.filename}` });
    });
  });

  // ──────────────────────────────────────────────
  // Páginas del panel de administración
  // ──────────────────────────────────────────────
  app.get('/admin', requireAuthPagina, (req, res) => {
    res.sendFile(path.join(__dirname, 'admin', 'dashboard.html'));
  });
  app.get('/admin/', requireAuthPagina, (req, res) => {
    res.sendFile(path.join(__dirname, 'admin', 'dashboard.html'));
  });
  app.get('/admin/dashboard.html', requireAuthPagina, (req, res) => {
    res.sendFile(path.join(__dirname, 'admin', 'dashboard.html'));
  });

  app.use('/admin', express.static(path.join(__dirname, 'admin')));

  // El dashboard depende de estos dos directorios de /public aunque
  // este contenedor NO sirva el sitio público completo:
  //  - /vendor/cropperjs -> lo usa admin/dashboard.html para recortar fotos
  //  - /img/anunciantes  -> para previsualizar imágenes ya subidas
  app.use('/vendor', express.static(path.join(__dirname, 'public', 'vendor')));
  app.use('/img/anunciantes', express.static(UPLOADS_DIR));

  // Si entran a la raíz del subdominio del panel, mándalos directo al login/dashboard.
  if (!SIRVE_WEB) {
    app.get('/', (req, res) => res.redirect('/admin'));
  }
}

if (SIRVE_WEB) {
  // ──────────────────────────────────────────────
  // API pública — la usa el carrusel de la página principal
  // ──────────────────────────────────────────────
  app.get('/api/anunciantes', (req, res) => {
    res.json(db.obtenerActivos());
  });

  // ──────────────────────────────────────────────
  // Sitio público (tu página tal como está hoy)
  // ──────────────────────────────────────────────
  app.use(express.static(path.join(__dirname, 'public')));
}

app.listen(PORT, () => {
  console.log(`Tropicalísima corriendo en http://localhost:${PORT} (ROLE=${ROLE})`);
  if (SIRVE_BACKEND) console.log(`Panel de administración en http://localhost:${PORT}/admin`);
  if (SIRVE_WEB) console.log(`Sitio público en http://localhost:${PORT}`);
});
